# FaceUnlock for Mac

A menu-bar app that unlocks your MacBook with your face using the built-in webcam — like Windows Hello.
It runs entirely on-device with Apple's Vision framework. No cloud, no third-party libraries.

## How it works

```
Screen locks ──► wait until you step away (or the display sleeps)
              ──► camera watches for your face (~14 fps)
              ──► face matches your enrolled template 3 frames in a row
              ──► you blink (liveness check, optional)
              ──► wakes display and types your password from Keychain ──► unlocked
```

| File | What it does |
|---|---|
| `AppDelegate.swift` | Menu-bar UI, lock/unlock state machine, safety limits |
| `CameraManager.swift` | AVFoundation webcam session, frame throttling |
| `FaceEngine.swift` | Face detection + landmarks, face "fingerprint" (Vision feature print), blink detector |
| `FaceStore.swift` | Saves your face template, auto-calibrates the match threshold |
| `FaceWindowController.swift` | Enroll / add samples / live test window |
| `KeychainStore.swift` | Verifies your password against macOS, stores it in Keychain |
| `Unlocker.swift` | Wakes the display and types the password with real key codes |

## Requirements

- macOS 13 Ventura or newer (Apple silicon or Intel)
- Xcode or Command Line Tools (`xcode-select --install`) for the `swift` command

## Build & install

```bash
cd FaceUnlock
chmod +x build.sh
./build.sh --install
```

The face icon appears in your menu bar.

Optional: open `Package.swift` in Xcode to edit and debug.

## Make a DMG to share

```bash
./make-dmg.sh
```

This creates `build/FaceUnlock-0.1.0.dmg`: open it, drag **FaceUnlock** onto **Applications**.

The app isn't notarized, so the first time someone opens it macOS will say it can't verify the developer. They should Control-click the app → **Open** → **Open**, or go to System Settings → Privacy & Security → **Open Anyway**. To remove that warning you need an Apple Developer account ($99/year) and must notarize the app.

## First-time setup (from the menu-bar icon)

1. **Enroll Face…** Look at the camera and slowly turn your head a little. It takes 20 samples.
2. **Mac password saved.** Enter your login password. It's checked against your account before it's saved.
3. **Accessibility access.** Turn on FaceUnlock in System Settings → Privacy & Security → Accessibility. This is needed to type on the lock screen.
4. **Test Recognition…** Check the `distance` value. It should stay under `threshold` for you. Then ask someone else to look at the camera. Their distance should stay above it.
5. Optional: **Add Samples…** in different lighting (night, near a window) or with and without glasses.
6. Optional: **Open at Login**.

Then lock with ⌃⌘Q, walk away and come back.

### Tuning
- **Match Strictness**
  - Strict: fewer strangers get in.
  - Relaxed: works in more lighting.
- **Require Blink**
  - Blocks a printed photo.
  - If it misses your blinks, watch the `eyes` value in Test Recognition.

## Safety behaviours built in
- Doesn't unlock the moment you lock while still sitting there. You must leave the frame for 2 seconds or let the display sleep first.
- Won't unlock if more than one face is in view.
- The camera turns off after 60 seconds with no face. It turns back on when you wake the display (press any key).
- After 2 failed unlock attempts it turns itself off, so macOS doesn't lock you out.

## ⚠️ Honest limitations
- **This isn't Face ID.**
  - MacBook webcams have no depth or infrared sensor, and Vision has no face-identity model.
  - Matching uses a general image fingerprint of your face.
  - A determined person with a video of you on a phone could fool it. Don't rely on it on a work or shared machine.
- **It types your password.**
  - macOS doesn't let third-party apps unlock the lock screen any other way.
  - Your password is stored in Keychain and is held in the app's memory while it runs.
- **US / ABC keyboard layout is assumed** for typing special characters.
- **Not supported:**
  - The first login after a restart (FileVault): the app isn't running yet.
  - Approving `sudo` or System Settings prompts.
- **Ad-hoc signing:** every rebuild can reset Accessibility permission. Toggle it off and on again after a rebuild. To avoid this, sign with your Apple ID dev certificate:
  `SIGN_IDENTITY="Apple Development: you@example.com (TEAMID)" ./build.sh --install`

## Uninstall
Use **Delete Face Data & Password…** from the menu, quit the app, then delete `/Applications/FaceUnlock.app`.

## Ideas for v2
- Core ML face-recognition model (e.g. FaceNet / ArcFace), which is far more accurate than feature prints
- PAM module so `sudo` in Terminal accepts your face
- iPhone as a depth camera via Continuity Camera
- Encrypt the face template with a Keychain-held key
