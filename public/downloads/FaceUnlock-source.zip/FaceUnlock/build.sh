#!/usr/bin/env bash
# Builds FaceUnlock.app into ./build and (optionally) copies it to /Applications.
# Usage: ./build.sh            -> build only
#        ./build.sh --install  -> build and install to /Applications
set -euo pipefail
cd "$(dirname "$0")"

BUNDLE_ID="com.faceunlock.mac"

echo "▶ Compiling (release)…"
swift build -c release

APP="build/FaceUnlock.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp ".build/release/FaceUnlock" "$APP/Contents/MacOS/FaceUnlock"
cp "Resources/Info.plist" "$APP/Contents/Info.plist"

# App icon: Resources/AppIcon.png (1024×1024) → AppIcon.icns
if [[ -f Resources/AppIcon.png ]]; then
  echo "▶ Making app icon…"
  ICONSET="build/AppIcon.iconset"
  rm -rf "$ICONSET"; mkdir -p "$ICONSET"
  for size in 16 32 128 256 512; do
    sips -z $size $size Resources/AppIcon.png --out "$ICONSET/icon_${size}x${size}.png" >/dev/null
    double=$((size * 2))
    sips -z $double $double Resources/AppIcon.png --out "$ICONSET/icon_${size}x${size}@2x.png" >/dev/null
  done
  iconutil -c icns "$ICONSET" -o "$APP/Contents/Resources/AppIcon.icns"
  rm -rf "$ICONSET"
fi

# Use your Apple Development identity if you have one (keeps permissions across rebuilds),
# otherwise fall back to ad-hoc signing.
IDENTITY="${SIGN_IDENTITY:--}"
echo "▶ Signing with identity: $IDENTITY"
codesign --force --deep --sign "$IDENTITY" "$APP"

echo "✅ Built $APP"

if [[ "${1:-}" == "--install" ]]; then
  pkill -x FaceUnlock 2>/dev/null || true
  rm -rf /Applications/FaceUnlock.app
  cp -R "$APP" /Applications/
  touch /Applications/FaceUnlock.app   # refresh the Finder / Dock icon cache

  if [[ "$IDENTITY" == "-" ]]; then
    # Ad-hoc builds get a new identity every time, so the old Accessibility
    # entry no longer matches. Clear it so the next grant is clean.
    tccutil reset Accessibility "$BUNDLE_ID" >/dev/null 2>&1 || true
    echo "ℹ️  Accessibility was reset for this new build. Grant it again from the menu-bar panel."
  fi

  echo "✅ Installed to /Applications/FaceUnlock.app"
  open /Applications/FaceUnlock.app
fi
