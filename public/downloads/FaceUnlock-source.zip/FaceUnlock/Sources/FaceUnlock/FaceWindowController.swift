import AppKit
import AVFoundation
import SwiftUI
import Vision

// MARK: - Model

/// Drives the scan window. Enrollment works like iPhone Face ID: a ring of
/// ticks fills in the direction you move your head until the circle is complete.
@MainActor
final class FaceScanModel: ObservableObject {
    enum Mode { case enroll, addSamples, test }
    enum Match { case searching, recognized, needsBlink, rejected }

    static let tickCount = 72

    let mode: Mode
    @Published var message = "Starting camera…"
    @Published var ticks = [Bool](repeating: false, count: FaceScanModel.tickCount)
    @Published var hint = ""
    @Published var hintAngle: Double?   // where the next unfilled part of the ring is (0 = up, clockwise)
    @Published var faceInFrame = false
    @Published var done = false
    @Published var match: Match = .searching
    @Published var detail = ""

    var onFinished: (() -> Void)?

    private var samples: [VNFeaturePrintObservation] = []
    private var lastSampleAt = Date.distantPast
    private var baselinePoints: [CGPoint] = []
    private var baseline: CGPoint?
    private var startedAt: Date?
    private let blink = BlinkDetector()

    init(mode: Mode) { self.mode = mode }

    var filledCount: Int { ticks.filter { $0 }.count }

    var title: String {
        switch mode {
        case .enroll: return done ? "Face Unlock Is Set Up" : "Set Up Face Unlock"
        case .addSamples: return done ? "Samples Added" : "Add Face Samples"
        case .test: return "Test Face Unlock"
        }
    }

    func handle(_ a: FaceAnalysis) {
        mode == .test ? handleTest(a) : handleEnroll(a)
    }

    // MARK: Enrollment

    private func handleEnroll(_ a: FaceAnalysis) {
        guard !done else { return }
        let now = Date()

        guard a.faceCount > 0 else {
            faceInFrame = false
            message = "Position your face within the circle."
            hint = ""; hintAngle = nil
            return
        }
        if a.faceCount > 1 { faceInFrame = false; message = "Only one face, please."; return }
        if a.faceWidthFraction < 0.15 { faceInFrame = false; message = "Move a little closer."; return }
        guard let nose = a.noseOffset, let print = a.featurePrint else { return }
        faceInFrame = true
        if startedAt == nil { startedAt = now }

        // 1. Learn where "looking straight" is.
        guard let base = baseline else {
            baselinePoints.append(nose)
            if now.timeIntervalSince(lastSampleAt) >= 0.15 {
                samples.append(print)
                lastSampleAt = now
            }
            message = "Look straight at the camera."
            if baselinePoints.count >= 6 {
                let n = CGFloat(baselinePoints.count)
                baseline = CGPoint(x: baselinePoints.reduce(0) { $0 + $1.x } / n,
                                   y: baselinePoints.reduce(0) { $0 + $1.y } / n)
            }
            return
        }

        // 2. Fill the ring in the direction the head is pointing.
        // The preview is mirrored, so flip x to match what you see.
        let x = -(nose.x - base.x)
        let y = nose.y - base.y
        if hypot(x, y) > 0.045 {
            var angle = atan2(Double(x), Double(y)) * 180 / .pi
            if angle < 0 { angle += 360 }
            let step = 360.0 / Double(Self.tickCount)
            let center = Int((angle / step).rounded()) % Self.tickCount
            var newlyFilled = false
            for k in -3...3 {
                let i = (center + k + Self.tickCount) % Self.tickCount
                if !ticks[i] { ticks[i] = true; newlyFilled = true }
            }
            if newlyFilled && now.timeIntervalSince(lastSampleAt) >= 0.12 {
                samples.append(print)
                lastSampleAt = now
            }
        }

        message = "Move your head slowly to complete the circle."
        updateHint()

        let ringDone = filledCount >= Int(Double(Self.tickCount) * 0.88)
        let tookTooLong = now.timeIntervalSince(startedAt ?? now) > 45 && samples.count >= 15
        if (ringDone && samples.count >= 12) || tookTooLong { finishEnrollment() }
    }

    /// Points you at the biggest unfilled part of the ring.
    private func updateHint() {
        var bestStart = -1, bestLength = 0
        let n = Self.tickCount
        for start in 0..<n where !ticks[start] && ticks[(start - 1 + n) % n] || (start == 0 && filledCount == 0) {
            var length = 0
            while length < n && !ticks[(start + length) % n] { length += 1 }
            if length > bestLength { bestLength = length; bestStart = start }
        }
        guard bestStart >= 0, bestLength > 0 else { hint = ""; hintAngle = nil; return }
        let mid = Double(bestStart) + Double(bestLength - 1) / 2
        let angle = (mid * 360 / Double(n)).truncatingRemainder(dividingBy: 360)
        hintAngle = angle
        hint = Self.direction(for: angle)
    }

    private static func direction(for angle: Double) -> String {
        switch angle {
        case 337.5..., ..<22.5: return "Tilt your head up"
        case 22.5..<67.5: return "Look up and to the right"
        case 67.5..<112.5: return "Turn your head right"
        case 112.5..<157.5: return "Look down and to the right"
        case 157.5..<202.5: return "Tilt your head down"
        case 202.5..<247.5: return "Look down and to the left"
        case 247.5..<292.5: return "Turn your head left"
        default: return "Look up and to the left"
        }
    }

    private func finishEnrollment() {
        ticks = [Bool](repeating: true, count: Self.tickCount)
        hint = ""; hintAngle = nil
        do {
            try FaceStore.shared.save(samples, append: mode == .addSamples)
            message = mode == .addSamples
                ? "Face Unlock now works in more conditions."
                : "Lock your Mac, then just look and blink to get back in."
        } catch {
            message = "Couldn't save: \(error.localizedDescription)"
        }
        done = true
        onFinished?()
    }

    // MARK: Test

    private func handleTest(_ a: FaceAnalysis) {
        blink.feed(a.eyeOpenness)
        let threshold = FaceStore.shared.effectiveThreshold

        guard a.faceCount > 0, let print = a.featurePrint,
              let distance = FaceStore.shared.distance(to: print) else {
            match = .searching
            message = "Looking for your face…"
            detail = ""
            return
        }

        let isMatch = distance <= threshold && a.faceCount == 1
        let blinked = blink.blinked(within: 4)

        if a.faceCount > 1 {
            match = .rejected
            message = "More than one face in view"
        } else if isMatch && (blinked || !Settings.shared.requireBlink) {
            match = .recognized
            message = "Recognized — this would unlock"
        } else if isMatch {
            match = .needsBlink
            message = "Recognized — blink to confirm"
        } else {
            match = .rejected
            message = "Not recognized"
        }
        detail = String(format: "match %.2f · limit %.2f", distance, threshold)
    }
}

// MARK: - View

struct FaceScanView: View {
    @ObservedObject var model: FaceScanModel
    let session: AVCaptureSession
    let onClose: () -> Void

    private let previewSize: CGFloat = 200
    private let ringRadius: CGFloat = 122

    var body: some View {
        VStack(spacing: 18) {
            ZStack {
                CameraPreview(session: session)
                    .frame(width: previewSize, height: previewSize)
                    .clipShape(Circle())
                    .opacity(model.done ? 0.3 : 1)
                    .blur(radius: model.done ? 6 : 0)

                if model.mode == .test {
                    testRing
                } else {
                    tickRing
                    directionArrow
                }

                if model.done {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 72, weight: .medium))
                        .foregroundStyle(.white, .green)
                        .transition(.scale(scale: 0.4).combined(with: .opacity))
                }
            }
            .frame(width: 290, height: 290)
            .animation(.spring(response: 0.45, dampingFraction: 0.6), value: model.done)

            VStack(spacing: 6) {
                Text(model.title)
                    .font(.system(size: 19, weight: .semibold))
                Text(model.message)
                    .font(.system(size: 13))
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .frame(minHeight: 34, alignment: .top)
                if !model.hint.isEmpty {
                    Text(model.hint)
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Color.green)
                        .transition(.opacity)
                }
                if model.mode == .test && !model.detail.isEmpty {
                    Text(model.detail)
                        .font(.system(size: 10.5).monospacedDigit())
                        .foregroundStyle(.tertiary)
                }
            }
            .animation(.easeInOut(duration: 0.2), value: model.hint)

            Button(action: onClose) {
                Text(model.done || model.mode == .test ? "Done" : "Cancel")
                    .frame(width: 120)
            }
            .controlSize(.large)
            .buttonStyle(.borderedProminent)
            .tint(model.done ? Color.green : Color.accentColor)
            .keyboardShortcut(.defaultAction)
        }
        .padding(.horizontal, 28)
        .padding(.top, 30)
        .padding(.bottom, 24)
        .frame(width: 360)
        .background(VisualEffectBackground(material: .hudWindow).ignoresSafeArea())
        .overlay(GlassSheen(radius: 12).ignoresSafeArea())
    }

    /// iPhone-style ring of ticks that turn green as you move your head.
    private var tickRing: some View {
        ZStack {
            ForEach(0..<FaceScanModel.tickCount, id: \.self) { i in
                let filled = model.ticks[i]
                Capsule()
                    .fill(filled ? Color.green : Color.primary.opacity(model.faceInFrame ? 0.28 : 0.15))
                    .frame(width: 3, height: filled ? 18 : 11)
                    .offset(y: -ringRadius)
                    .rotationEffect(.degrees(Double(i) * 360 / Double(FaceScanModel.tickCount)))
                    .animation(.easeOut(duration: 0.25), value: filled)
            }
        }
    }

    /// A small chevron outside the ring pointing to where you should move next.
    @ViewBuilder private var directionArrow: some View {
        if let angle = model.hintAngle, !model.done, model.filledCount > 0 {
            Image(systemName: "chevron.up")
                .font(.system(size: 16, weight: .bold))
                .foregroundStyle(Color.green)
                .offset(y: -(ringRadius + 22))
                .rotationEffect(.degrees(angle))
                .animation(.easeInOut(duration: 0.3), value: angle)
        }
    }

    private var testRing: some View {
        Circle()
            .trim(from: 0, to: model.match == .searching ? 0 : 1)
            .stroke(testColor, style: StrokeStyle(lineWidth: 5, lineCap: .round))
            .rotationEffect(.degrees(-90))
            .frame(width: previewSize + 22, height: previewSize + 22)
            .animation(.easeOut(duration: 0.3), value: model.match)
    }

    private var testColor: Color {
        switch model.match {
        case .recognized: return .green
        case .needsBlink: return .orange
        case .rejected: return .red
        case .searching: return .clear
        }
    }
}

/// Live, mirrored webcam preview.
struct CameraPreview: NSViewRepresentable {
    let session: AVCaptureSession

    func makeNSView(context: Context) -> PreviewView { PreviewView(session: session) }
    func updateNSView(_ nsView: PreviewView, context: Context) {}

    final class PreviewView: NSView {
        private let previewLayer: AVCaptureVideoPreviewLayer

        init(session: AVCaptureSession) {
            previewLayer = AVCaptureVideoPreviewLayer(session: session)
            super.init(frame: .zero)
            wantsLayer = true
            layer?.backgroundColor = NSColor.black.cgColor
            previewLayer.videoGravity = .resizeAspectFill
            previewLayer.setAffineTransform(CGAffineTransform(scaleX: -1, y: 1)) // mirror
            layer?.addSublayer(previewLayer)
        }

        @available(*, unavailable)
        required init?(coder: NSCoder) { fatalError("not supported") }

        override func layout() {
            super.layout()
            previewLayer.frame = bounds
        }
    }
}

// MARK: - Window

@MainActor
final class FaceWindowController: NSWindowController, NSWindowDelegate {
    typealias Mode = FaceScanModel.Mode

    private let camera: CameraManager
    private let model: FaceScanModel
    var onClose: (() -> Void)?

    init(mode: Mode, camera: CameraManager) {
        self.camera = camera
        self.model = FaceScanModel(mode: mode)

        let window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 360, height: 520),
                              styleMask: [.titled, .closable, .fullSizeContentView],
                              backing: .buffered, defer: false)
        window.titlebarAppearsTransparent = true
        window.titleVisibility = .hidden
        window.isMovableByWindowBackground = true
        window.isOpaque = false
        window.backgroundColor = .clear
        window.isReleasedWhenClosed = false
        window.level = .floating                       // stay above other apps' windows
        window.collectionBehavior = [.moveToActiveSpace, .fullScreenAuxiliary]
        window.standardWindowButton(.miniaturizeButton)?.isHidden = true
        window.standardWindowButton(.zoomButton)?.isHidden = true

        super.init(window: window)
        window.delegate = self

        let view = FaceScanView(model: model, session: camera.session) { [weak window] in
            window?.close()
        }
        let hosting = NSHostingView(rootView: view)
        window.contentView = hosting
        window.setContentSize(hosting.fittingSize)

        model.onFinished = { [weak self] in
            self?.camera.onAnalysis = nil
            self?.camera.stop()
        }
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("not supported") }

    func present() {
        guard let window else { return }
        window.center()
        showWindow(nil)
        bringToFront(window)
        // The menu-bar popover is still closing; bring the window forward again once it has.
        Task { @MainActor [weak self, weak window] in
            try? await Task.sleep(nanoseconds: 250_000_000)
            if let self, let window { self.bringToFront(window) }
        }

        CameraManager.requestAccess { [weak self] granted in
            guard let self else { return }
            guard granted else {
                self.model.message = "Allow camera access in System Settings → Privacy & Security → Camera."
                return
            }
            self.camera.minFrameInterval = self.model.mode == .test ? 0.07 : 0.08
            self.camera.onAnalysis = { [weak self] analysis in self?.model.handle(analysis) }
            self.camera.start()
        }
    }

    private func bringToFront(_ window: NSWindow) {
        if #available(macOS 14.0, *) {
            NSApp.activate()
        } else {
            NSApp.activate(ignoringOtherApps: true)
        }
        window.orderFrontRegardless()
        window.makeKeyAndOrderFront(nil)
    }

    func windowWillClose(_ notification: Notification) {
        camera.onAnalysis = nil
        camera.stop()
        onClose?()
    }
}
