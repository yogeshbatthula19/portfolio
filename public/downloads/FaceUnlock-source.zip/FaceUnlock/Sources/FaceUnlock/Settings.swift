import Foundation

enum Strictness: String, CaseIterable {
    case strict, normal, relaxed

    /// Multiplier applied to the calibrated base threshold.
    var factor: Float {
        switch self {
        case .strict: return 1.3
        case .normal: return 1.6
        case .relaxed: return 2.0
        }
    }

    var shortTitle: String {
        switch self {
        case .strict: return "Strict"
        case .normal: return "Balanced"
        case .relaxed: return "Relaxed"
        }
    }

    var title: String {
        switch self {
        case .strict: return "Strict (fewer false accepts)"
        case .normal: return "Normal"
        case .relaxed: return "Relaxed (works in more lighting)"
        }
    }
}

final class Settings {
    static let shared = Settings()
    private let d = UserDefaults.standard

    var enabled: Bool {
        get { d.object(forKey: "enabled") as? Bool ?? true }
        set { d.set(newValue, forKey: "enabled") }
    }

    /// Require a blink before unlocking (basic anti-photo liveness check).
    var requireBlink: Bool {
        get { d.object(forKey: "requireBlink") as? Bool ?? true }
        set { d.set(newValue, forKey: "requireBlink") }
    }

    /// Show the 🔒 → 🔓 overlay after a face unlock.
    var showUnlockAnimation: Bool {
        get { d.object(forKey: "showUnlockAnimation") as? Bool ?? true }
        set { d.set(newValue, forKey: "showUnlockAnimation") }
    }

    var strictness: Strictness {
        get { Strictness(rawValue: d.string(forKey: "strictness") ?? "") ?? .normal }
        set { d.set(newValue.rawValue, forKey: "strictness") }
    }
}
