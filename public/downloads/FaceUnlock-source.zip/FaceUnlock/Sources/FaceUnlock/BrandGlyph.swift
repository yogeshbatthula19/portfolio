import AppKit

/// The Face ID-style glyph from the app icon, drawn as a template image so the
/// menu-bar icon matches the Dock / Finder icon exactly (same corners, eyes, nose, smile).
enum BrandGlyph {
    static func menuBarImage(size: CGFloat = 18) -> NSImage {
        let image = NSImage(size: NSSize(width: size, height: size), flipped: true) { rect in
            let s = rect.width / 24 // glyph is designed on a 24-unit grid
            func p(_ x: CGFloat, _ y: CGFloat) -> NSPoint { NSPoint(x: x * s, y: y * s) }

            let path = NSBezierPath()
            path.lineWidth = 1.9 * s
            path.lineCapStyle = .round
            path.lineJoinStyle = .round

            // Four rounded corner brackets.
            let r: CGFloat = 2.6
            path.move(to: p(3, 8));  path.line(to: p(3, 3 + r))
            path.curve(to: p(3 + r, 3), controlPoint1: p(3, 3), controlPoint2: p(3, 3))
            path.line(to: p(8, 3))
            path.move(to: p(16, 3)); path.line(to: p(21 - r, 3))
            path.curve(to: p(21, 3 + r), controlPoint1: p(21, 3), controlPoint2: p(21, 3))
            path.line(to: p(21, 8))
            path.move(to: p(21, 16)); path.line(to: p(21, 21 - r))
            path.curve(to: p(21 - r, 21), controlPoint1: p(21, 21), controlPoint2: p(21, 21))
            path.line(to: p(16, 21))
            path.move(to: p(8, 21)); path.line(to: p(3 + r, 21))
            path.curve(to: p(3, 21 - r), controlPoint1: p(3, 21), controlPoint2: p(3, 21))
            path.line(to: p(3, 16))

            // Eyes.
            path.move(to: p(9, 9));  path.line(to: p(9, 10.6))
            path.move(to: p(15, 9)); path.line(to: p(15, 10.6))
            // Nose.
            path.move(to: p(12, 9)); path.line(to: p(12, 13)); path.line(to: p(11, 13))
            // Smile.
            path.move(to: p(8.92, 16.87))
            path.curve(to: p(15.08, 16.87), controlPoint1: p(10.2, 19.2), controlPoint2: p(13.8, 19.2))

            NSColor.black.setStroke()
            path.stroke()
            return true
        }
        image.isTemplate = true
        return image
    }
}
