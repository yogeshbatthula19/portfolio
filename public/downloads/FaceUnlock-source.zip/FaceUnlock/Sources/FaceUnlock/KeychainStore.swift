import Foundation
import OpenDirectory
import Security

/// Keeps your Mac login password in the login Keychain.
enum KeychainStore {
    private static let service = "FaceUnlock.login-password"
    private static var account: String { NSUserName() }

    @discardableResult
    static func save(_ password: String) -> Bool {
        delete()
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecAttrLabel as String: "FaceUnlock",
            kSecValueData as String: Data(password.utf8),
        ]
        return SecItemAdd(query as CFDictionary, nil) == errSecSuccess
    }

    static func load() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess,
              let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func delete() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
        ]
        SecItemDelete(query as CFDictionary)
    }

    /// Checks the password against your macOS account so we never type a wrong one
    /// on the lock screen (which could trigger lockouts).
    static func verifyLoginPassword(_ password: String) -> Bool {
        do {
            // "/Search" is the authentication search node (works for local and network accounts).
            let node = try ODNode(session: ODSession.default(), name: "/Search")
            let record = try node.record(withRecordType: kODRecordTypeUsers,
                                         name: NSUserName(), attributes: [String]())
            try record.verifyPassword(password)
            return true
        } catch {
            return false
        }
    }
}
