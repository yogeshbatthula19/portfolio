import ApplicationServices
import CoreGraphics
import Foundation
import IOKit.pwr_mgt

/// macOS has no public API for third-party apps to unlock the lock screen,
/// so FaceUnlock wakes the display and types your password as keystrokes.
/// This needs Accessibility permission.
enum Unlocker {
    static func isTrusted(prompt: Bool) -> Bool {
        let options = ["AXTrustedCheckOptionPrompt": prompt] as CFDictionary
        return AXIsProcessTrustedWithOptions(options)
    }

    /// True while the lock screen (or a password-protected screen saver) is up.
    static func isScreenLocked() -> Bool {
        guard let dict = CGSessionCopyCurrentDictionary() as? [String: Any] else { return false }
        return (dict["CGSSessionScreenIsLocked"] as? NSNumber)?.boolValue ?? false
    }

    static func wakeDisplay() {
        var assertionID: IOPMAssertionID = 0
        _ = IOPMAssertionDeclareUserActivity("FaceUnlock" as CFString, kIOPMUserActiveLocal, &assertionID)
    }

    static func lockScreenNow() {
        // Sleeps the display; locks immediately if "Require password immediately" is set.
        let task = Process()
        task.executableURL = URL(fileURLWithPath: "/usr/bin/pmset")
        task.arguments = ["displaysleepnow"]
        try? task.run()
    }

    static func unlock(password: String) {
        wakeDisplay()
        DispatchQueue.global(qos: .userInteractive).async {
            guard isScreenLocked() else { return }
            usleep(800_000)
            let source = CGEventSource(stateID: .hidSystemState)
            // A lone Shift tap dismisses the screen saver / reveals the password
            // field without typing anything.
            tap(56, shift: false, source: source)
            usleep(900_000)
            // Never type a password into a normal app: only continue while locked.
            guard isScreenLocked() else { return }
            tap(56, shift: false, source: source)
            usleep(400_000)
            for ch in password {
                if let (code, shift) = KeyMap.usANSI[ch] {
                    tap(code, shift: shift, source: source)
                } else {
                    typeUnicode(ch, source: source)
                }
                usleep(25_000)
            }
            tap(36, shift: false, source: source) // Return
        }
    }

    private static func tap(_ code: CGKeyCode, shift: Bool, source: CGEventSource?) {
        let shiftCode: CGKeyCode = 56
        if shift {
            let sd = CGEvent(keyboardEventSource: source, virtualKey: shiftCode, keyDown: true)
            sd?.flags = .maskShift
            sd?.post(tap: .cghidEventTap)
        }
        let down = CGEvent(keyboardEventSource: source, virtualKey: code, keyDown: true)
        let up = CGEvent(keyboardEventSource: source, virtualKey: code, keyDown: false)
        if shift {
            down?.flags = .maskShift
            up?.flags = .maskShift
        }
        down?.post(tap: .cghidEventTap)
        up?.post(tap: .cghidEventTap)
        if shift {
            CGEvent(keyboardEventSource: source, virtualKey: shiftCode, keyDown: false)?
                .post(tap: .cghidEventTap)
        }
    }

    private static func typeUnicode(_ ch: Character, source: CGEventSource?) {
        var utf16 = Array(String(ch).utf16)
        let down = CGEvent(keyboardEventSource: source, virtualKey: 0, keyDown: true)
        let up = CGEvent(keyboardEventSource: source, virtualKey: 0, keyDown: false)
        down?.keyboardSetUnicodeString(stringLength: utf16.count, unicodeString: &utf16)
        up?.keyboardSetUnicodeString(stringLength: utf16.count, unicodeString: &utf16)
        down?.post(tap: .cghidEventTap)
        up?.post(tap: .cghidEventTap)
    }
}

/// Virtual key codes for the US / ABC keyboard layout.
/// Secure password fields often ignore synthetic Unicode text, so we send real key codes.
enum KeyMap {
    static let usANSI: [Character: (CGKeyCode, Bool)] = {
        var map: [Character: (CGKeyCode, Bool)] = [:]
        let plain: [(Character, CGKeyCode)] = [
            ("a", 0), ("s", 1), ("d", 2), ("f", 3), ("h", 4), ("g", 5), ("z", 6), ("x", 7),
            ("c", 8), ("v", 9), ("b", 11), ("q", 12), ("w", 13), ("e", 14), ("r", 15),
            ("y", 16), ("t", 17), ("1", 18), ("2", 19), ("3", 20), ("4", 21), ("6", 22),
            ("5", 23), ("=", 24), ("9", 25), ("7", 26), ("-", 27), ("8", 28), ("0", 29),
            ("]", 30), ("o", 31), ("u", 32), ("[", 33), ("i", 34), ("p", 35), ("l", 37),
            ("j", 38), ("'", 39), ("k", 40), (";", 41), ("\\", 42), (",", 43), ("/", 44),
            ("n", 45), ("m", 46), (".", 47), (" ", 49), ("`", 50),
        ]
        for (ch, code) in plain {
            map[ch] = (code, false)
            if ch.isLetter, let upper = ch.uppercased().first { map[upper] = (code, true) }
        }
        let shifted: [(Character, CGKeyCode)] = [
            ("!", 18), ("@", 19), ("#", 20), ("$", 21), ("%", 23), ("^", 22), ("&", 26),
            ("*", 28), ("(", 25), (")", 29), ("_", 27), ("+", 24), ("{", 33), ("}", 30),
            ("|", 42), (":", 41), ("\"", 39), ("<", 43), (">", 47), ("?", 44), ("~", 50),
        ]
        for (ch, code) in shifted { map[ch] = (code, true) }
        return map
    }()
}
