import SwiftUI

/// The menu-bar popover: one main switch, a couple of toggles, nothing else in the way.
struct MenuView: View {
    @ObservedObject var state: AppState

    var body: some View {
        VStack(spacing: 14) {
            header

            if let error = state.lastError {
                Banner(text: error)
            }

            if state.isReady {
                optionsCard
            } else {
                setupCard
            }

            footer
        }
        .padding(16)
        .frame(width: 300)
    }

    // MARK: Header — icon, name, status, master switch

    private var header: some View {
        HStack(spacing: 12) {
            // The real app icon, so the popover, Dock and Finder all match.
            Image(nsImage: NSApp.applicationIconImage)
                .resizable()
                .interpolation(.high)
                .frame(width: 44, height: 44)
                .saturation(state.lastError != nil ? 0.2 : (state.isReady && state.enabled ? 1 : 0.35))

            VStack(alignment: .leading, spacing: 2) {
                Text("Face Unlock")
                    .font(.system(size: 14, weight: .semibold))
                Text(state.statusText)
                    .font(.system(size: 11))
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Toggle("", isOn: $state.enabled)
                .toggleStyle(.switch)
                .labelsHidden()
                .disabled(!state.isReady)
        }
    }

    private var iconColors: [Color] {
        if state.lastError != nil { return [.orange, .red] }
        if state.isReady && state.enabled { return [Color(red: 0.25, green: 0.6, blue: 1), Color(red: 0.45, green: 0.35, blue: 1)] }
        return [.gray.opacity(0.7), .gray]
    }

    // MARK: Setup (only until all 3 steps are done)

    private var setupCard: some View {
        GlassCard {
            SetupRow(number: 1, title: "Scan your face", done: state.enrolled) {
                state.actions?.enrollFace()
            }
            Divider().opacity(0.4)
            SetupRow(number: 2, title: "Save Mac password", done: state.hasPassword) {
                state.actions?.setPassword()
            }
            Divider().opacity(0.4)
            SetupRow(number: 3, title: "Allow Accessibility", done: state.accessibility) {
                state.actions?.grantAccessibility()
            }
        }
    }

    // MARK: Options — simple toggles

    private var optionsCard: some View {
        GlassCard {
            ToggleRow(icon: "eye", title: "Blink to confirm",
                      subtitle: "Stops photos from unlocking", isOn: $state.requireBlink)
            Divider().opacity(0.4)
            ToggleRow(icon: "lock.open", title: "Unlock animation",
                      subtitle: nil, isOn: $state.showAnimation)
            Divider().opacity(0.4)
            ToggleRow(icon: "power", title: "Open at login", subtitle: nil,
                      isOn: Binding(get: { state.launchAtLogin },
                                    set: { state.actions?.setLaunchAtLogin($0) }))
        }
    }

    // MARK: Footer — Test, Lock, and a quiet "…" for everything else

    private var footer: some View {
        HStack(spacing: 8) {
            PillButton(icon: "viewfinder", title: "Test") { state.actions?.testRecognition() }
                .disabled(!state.enrolled)
            PillButton(icon: "lock.fill", title: "Lock") { state.actions?.lockNow() }

            Spacer()

            Menu {
                if state.enrolled {
                    Button("Rescan Face…") { state.actions?.enrollFace() }
                    Button("Add Face Samples…") { state.actions?.addSamples() }
                    Picker("Match", selection: $state.strictness) {
                        ForEach(Strictness.allCases, id: \.self) { level in
                            Text(level.shortTitle).tag(level)
                        }
                    }
                    Divider()
                }
                Button("Change Password…") { state.actions?.setPassword() }
                Button("Delete Face Data…") { state.actions?.deleteAll() }
                Divider()
                Button("Quit Face Unlock") { state.actions?.quit() }
            } label: {
                Image(systemName: "ellipsis")
                    .font(.system(size: 13, weight: .semibold))
                    .frame(width: 28, height: 28)
                    .background(Color.primary.opacity(0.08), in: Circle())
            }
            .menuStyle(.borderlessButton)
            .menuIndicator(.hidden)
            .fixedSize()
        }
    }
}

// MARK: - Building blocks

struct GlassCard<Content: View>: View {
    @ViewBuilder var content: Content

    var body: some View {
        VStack(spacing: 0) { content }
            .padding(.horizontal, 12)
            .padding(.vertical, 4)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(.ultraThinMaterial)
            )
            .overlay(GlassSheen(radius: 14))
    }
}

/// Glass edge: a bright top-left rim that fades out, plus a soft sheen across the top.
struct GlassSheen: View {
    var radius: CGFloat

    var body: some View {
        let shape = RoundedRectangle(cornerRadius: radius, style: .continuous)
        ZStack {
            shape.fill(LinearGradient(colors: [Color.white.opacity(0.16), .clear],
                                      startPoint: .top, endPoint: .center))
            shape.strokeBorder(LinearGradient(
                colors: [Color.white.opacity(0.6), Color.white.opacity(0.08), Color.white.opacity(0.28)],
                startPoint: .topLeading, endPoint: .bottomTrailing), lineWidth: 1)
        }
        .allowsHitTesting(false)
    }
}

struct ToggleRow: View {
    let icon: String
    let title: String
    let subtitle: String?
    @Binding var isOn: Bool

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: icon)
                .font(.system(size: 13))
                .foregroundStyle(.secondary)
                .frame(width: 18)
            VStack(alignment: .leading, spacing: 1) {
                Text(title).font(.system(size: 13))
                if let subtitle {
                    Text(subtitle).font(.system(size: 10.5)).foregroundStyle(.tertiary)
                }
            }
            Spacer()
            Toggle("", isOn: $isOn)
                .toggleStyle(.switch)
                .controlSize(.small)
                .labelsHidden()
        }
        .padding(.vertical, 8)
    }
}

struct SetupRow: View {
    let number: Int
    let title: String
    let done: Bool
    let action: () -> Void

    var body: some View {
        HStack(spacing: 10) {
            ZStack {
                Circle()
                    .fill(done ? Color.green : Color.primary.opacity(0.08))
                if done {
                    Image(systemName: "checkmark")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(.white)
                } else {
                    Text("\(number)")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundStyle(.secondary)
                }
            }
            .frame(width: 22, height: 22)

            Text(title)
                .font(.system(size: 13))
                .foregroundStyle(done ? Color.secondary : Color.primary)

            Spacer()

            if !done {
                Button("Set Up", action: action)
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
            }
        }
        .padding(.vertical, 9)
    }
}

struct PillButton: View {
    let icon: String
    let title: String
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.system(size: 12, weight: .medium))
                .padding(.horizontal, 12)
                .padding(.vertical, 6)
                .background(Color.primary.opacity(0.08), in: Capsule())
        }
        .buttonStyle(.plain)
    }
}

struct Banner: View {
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(.orange)
            Text(text)
                .font(.system(size: 11.5))
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
        }
        .padding(10)
        .background(
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Color.orange.opacity(0.12))
        )
    }
}

/// Real "behind window" blur for the glass look.
struct VisualEffectBackground: NSViewRepresentable {
    var material: NSVisualEffectView.Material = .hudWindow

    func makeNSView(context: Context) -> NSVisualEffectView {
        let view = NSVisualEffectView()
        view.material = material
        view.blendingMode = .behindWindow
        view.state = .active
        return view
    }

    func updateNSView(_ nsView: NSVisualEffectView, context: Context) {
        nsView.material = material
    }
}
