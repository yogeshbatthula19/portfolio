import AppKit
import ServiceManagement
import SwiftUI

@main
@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate, AppActions {
    static func main() {
        let app = NSApplication.shared
        let delegate = AppDelegate()
        app.delegate = delegate
        app.setActivationPolicy(.accessory) // menu-bar only, no Dock icon
        app.run()
    }

    // MARK: State

    private enum ScanState {
        case idle               // unlocked, camera off
        case waitingForAbsence  // just locked: wait until you leave (or the display wakes)
        case armed              // looking for your face
        case paused             // locked, camera off to save battery; resumes on wake
        case typing             // password being typed
    }

    let appState = AppState()

    private var statusItem: NSStatusItem!
    private let popover = NSPopover()
    private let camera = CameraManager()
    private let blink = BlinkDetector()
    private var faceWindow: FaceWindowController?

    private var scanState: ScanState = .idle
    private var lockedAt = Date()
    private var absentSince: Date?
    private var lastFaceSeen = Date()
    private var consecutiveMatches = 0
    private var failedAttempts = 0
    private var lastSystemWake = Date.distantPast

    /// Cached at launch so we never need a Keychain prompt while the screen is locked.
    private var cachedPassword: String? {
        didSet { appState.hasPassword = cachedPassword != nil }
    }

    // MARK: Launch

    func applicationDidFinishLaunching(_ notification: Notification) {
        appState.actions = self
        cachedPassword = KeychainStore.load()
        appState.refresh()

        statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        statusItem.button?.target = self
        statusItem.button?.action = #selector(togglePopover)
        updateIcon()

        let hosting = NSHostingController(rootView: MenuView(state: appState))
        hosting.sizingOptions = .preferredContentSize
        popover.contentViewController = hosting
        popover.behavior = .transient
        popover.animates = true

        let dnc = DistributedNotificationCenter.default()
        dnc.addObserver(self, selector: #selector(screenLocked),
                        name: NSNotification.Name("com.apple.screenIsLocked"), object: nil)
        dnc.addObserver(self, selector: #selector(screenUnlocked),
                        name: NSNotification.Name("com.apple.screenIsUnlocked"), object: nil)
        let wnc = NSWorkspace.shared.notificationCenter
        wnc.addObserver(self, selector: #selector(screenWoke),
                        name: NSWorkspace.screensDidWakeNotification, object: nil)
        wnc.addObserver(self, selector: #selector(screenWoke),
                        name: NSWorkspace.didWakeNotification, object: nil)
        wnc.addObserver(self, selector: #selector(systemWillSleep),
                        name: NSWorkspace.willSleepNotification, object: nil)
        wnc.addObserver(self, selector: #selector(systemWillSleep),
                        name: NSWorkspace.screensDidSleepNotification, object: nil)
        dnc.addObserver(self, selector: #selector(screenSaverStarted),
                        name: NSNotification.Name("com.apple.screensaver.didstart"), object: nil)
        dnc.addObserver(self, selector: #selector(screenSaverStopped),
                        name: NSNotification.Name("com.apple.screensaver.didstop"), object: nil)

        // Launched while the Mac is already locked (e.g. login item started late).
        if Unlocker.isScreenLocked() { beginLockedSession() }

        if !appState.accessibility { watchForAccessibility() }

        // First run: open the popover so the 3 setup steps are right there.
        if !appState.isReady {
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 500_000_000)
                self.showPopover()
            }
        }
    }

    private var isReady: Bool {
        appState.refresh()
        return appState.isReady
    }

    private func updateIcon() {
        let image: NSImage
        if appState.lastError != nil,
           let warning = NSImage(systemSymbolName: "exclamationmark.triangle", accessibilityDescription: "Face Unlock") {
            image = warning
        } else {
            image = BrandGlyph.menuBarImage() // same glyph as the app icon
        }
        image.isTemplate = true
        statusItem.button?.image = image
        statusItem.button?.appearsDisabled = !appState.enabled || !appState.isReady
    }

    // MARK: Popover

    @objc private func togglePopover() {
        popover.isShown ? popover.performClose(nil) : showPopover()
    }

    private func showPopover() {
        guard let button = statusItem.button else { return }
        appState.refresh()
        updateIcon()
        NSApp.activate(ignoringOtherApps: true)
        popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
    }

    private func closePopover() {
        if popover.isShown { popover.performClose(nil) }
    }

    // MARK: AppActions

    func enrollFace() { openFaceWindow(.enroll) }
    func addSamples() { openFaceWindow(.addSamples) }
    func testRecognition() { openFaceWindow(.test) }

    private func openFaceWindow(_ mode: FaceWindowController.Mode) {
        closePopover()
        faceWindow?.close()
        let controller = FaceWindowController(mode: mode, camera: camera)
        controller.onClose = { [weak self] in
            self?.faceWindow = nil
            self?.appState.refresh()
            self?.updateIcon()
        }
        faceWindow = controller
        controller.present()
    }

    func setPassword() {
        closePopover()
        let alert = NSAlert()
        alert.messageText = "Your Mac Password"
        alert.informativeText = "Saved securely in Keychain. Face Unlock types it for you after recognizing your face."
        let field = NSSecureTextField(frame: NSRect(x: 0, y: 0, width: 240, height: 24))
        field.placeholderString = "Password"
        alert.accessoryView = field
        alert.addButton(withTitle: "Save")
        alert.addButton(withTitle: "Cancel")
        alert.window.initialFirstResponder = field
        NSApp.activate(ignoringOtherApps: true)
        guard alert.runModal() == .alertFirstButtonReturn else { return }

        let password = field.stringValue
        guard KeychainStore.verifyLoginPassword(password) else {
            showMessage("Incorrect password", "That doesn't match your Mac account. Nothing was saved.")
            return
        }
        if KeychainStore.save(password) {
            cachedPassword = password
            failedAttempts = 0
            appState.lastError = nil
        } else {
            showMessage("Couldn't save to Keychain", "Please try again.")
        }
        updateIcon()
        showPopover()
    }

    func grantAccessibility() {
        closePopover()
        // Registers the app in the Accessibility list (and shows the system prompt).
        if !Unlocker.isTrusted(prompt: true),
           let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility") {
            NSWorkspace.shared.open(url)
        }
        watchForAccessibility()
    }

    /// Polls until Accessibility is granted, then updates the panel by itself —
    /// no need to quit and reopen the app.
    private var watchingAccessibility = false
    private func watchForAccessibility() {
        guard !watchingAccessibility else { return }
        watchingAccessibility = true
        Task { @MainActor [weak self] in
            for _ in 0..<300 { // up to ~5 minutes
                try? await Task.sleep(nanoseconds: 1_000_000_000)
                guard let self else { return }
                if Unlocker.isTrusted(prompt: false) {
                    self.appState.refresh()
                    self.updateIcon()
                    self.watchingAccessibility = false
                    NSApp.activate(ignoringOtherApps: true)
                    self.showPopover()
                    return
                }
            }
            self?.watchingAccessibility = false
        }
    }

    func lockNow() {
        closePopover()
        Unlocker.lockScreenNow()
    }

    func setLaunchAtLogin(_ on: Bool) {
        do {
            if on { try SMAppService.mainApp.register() } else { try SMAppService.mainApp.unregister() }
        } catch {
            showMessage("Couldn't change Open at Login", error.localizedDescription)
        }
        appState.refresh()
    }

    func deleteAll() {
        closePopover()
        let alert = NSAlert()
        alert.messageText = "Delete face data and password?"
        alert.informativeText = "Face Unlock will stop working until you set it up again."
        alert.addButton(withTitle: "Delete")
        alert.addButton(withTitle: "Cancel")
        alert.alertStyle = .warning
        NSApp.activate(ignoringOtherApps: true)
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        FaceStore.shared.reset()
        KeychainStore.delete()
        cachedPassword = nil
        appState.refresh()
        updateIcon()
    }

    func quit() { NSApp.terminate(nil) }

    private func showMessage(_ title: String, _ detail: String) {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = detail
        NSApp.activate(ignoringOtherApps: true)
        alert.runModal()
    }

    // MARK: Lock / unlock lifecycle

    @objc private func screenLocked() { beginLockedSession() }

    private func beginLockedSession() {
        guard appState.enabled, isReady, scanState == .idle || scanState == .paused else { return }
        closePopover()
        faceWindow?.close()
        lockedAt = Date()
        absentSince = nil
        // Lid just opened (macOS can report the lock *after* waking): you want in now.
        if Date().timeIntervalSince(lastSystemWake) < 15 {
            arm()
        } else {
            scanState = .waitingForAbsence
        }
        startScanning()
    }

    @objc private func screenUnlocked() { handleUnlocked() }

    private func handleUnlocked() {
        let unlockedByFace = scanState == .typing
        scanState = .idle
        stopScanning()
        failedAttempts = 0
        guard unlockedByFace, appState.showAnimation else { return }
        // The lock screen belongs to macOS and nothing can be drawn over it, so the
        // lock → unlock animation plays the moment the desktop is back.
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 450_000_000)
            UnlockHUD.show()
        }
    }

    /// Lid closed / Mac going to sleep / display off: release the camera cleanly.
    @objc private func systemWillSleep() {
        if scanState != .idle && scanState != .typing { pause() }
    }

    /// Screen saver kicked in. If it locks the Mac, start looking for you.
    @objc private func screenSaverStarted() {
        checkLockedSoon()
    }

    /// You touched the Mac while the screen saver was running: you want in.
    @objc private func screenSaverStopped() {
        switch scanState {
        case .paused, .waitingForAbsence:
            stopScanning(); arm(); startScanning()
        case .idle:
            checkLockedSoon()
        default:
            break
        }
    }

    /// Lid opened (system wake) or display woke from a key press.
    @objc private func screenWoke() {
        lastSystemWake = Date()
        switch scanState {
        case .paused, .waitingForAbsence, .armed:
            // You woke it: you want back in. Restart the camera because
            // AVCaptureSession can stay interrupted after sleep.
            stopScanning()
            arm()
            startScanning()
        case .idle:
            // macOS sometimes never delivers the "locked" notification for a
            // sleep-lock, so ask the session directly.
            checkLockedSoon()
        case .typing:
            break
        }
    }

    /// Looks a few times over ~9 s whether the Mac is locked while we think it isn't.
    private func checkLockedSoon() {
        Task { @MainActor [weak self] in
            for delay in [400, 1200, 2500, 5000] as [UInt64] {
                try? await Task.sleep(nanoseconds: delay * 1_000_000)
                guard let self, self.scanState == .idle || self.scanState == .paused else { return }
                if Unlocker.isScreenLocked() {
                    self.beginLockedSession()
                    return
                }
            }
        }
    }

    private func arm() {
        scanState = .armed
        lockedAt = Date()
        lastFaceSeen = Date()
        consecutiveMatches = 0
        blink.reset()
    }

    private func pause() {
        scanState = .paused
        stopScanning()
    }

    private var scanToken = 0
    private var lastAnalysisAt = Date()

    private func startScanning() {
        lastFaceSeen = Date()
        lastAnalysisAt = Date()
        scanToken += 1
        let token = scanToken
        // Watchdog: if the camera goes quiet after sleep, kick it.
        Task { @MainActor [weak self] in
            while true {
                try? await Task.sleep(nanoseconds: 3_000_000_000)
                guard let self, self.scanToken == token else { return }
                if Date().timeIntervalSince(self.lastAnalysisAt) > 4 {
                    self.camera.restart()
                    self.lastAnalysisAt = Date()
                }
            }
        }
        camera.minFrameInterval = 0.07 // ~14 fps so blinks aren't missed
        camera.onAnalysis = { [weak self] analysis in self?.process(analysis) }
        camera.start()
    }

    private func stopScanning() {
        scanToken += 1
        camera.onAnalysis = nil
        camera.stop()
    }

    private func process(_ a: FaceAnalysis) {
        let now = Date()
        lastAnalysisAt = now
        let hasFace = a.faceCount > 0
        if hasFace { lastFaceSeen = now }

        switch scanState {
        case .waitingForAbsence:
            // Don't unlock the instant you lock the screen while still sitting there.
            if hasFace {
                absentSince = nil
            } else {
                let since = absentSince ?? now
                absentSince = since
                if now.timeIntervalSince(since) >= 2 { arm() }
            }
            if now.timeIntervalSince(lockedAt) > 60 { pause() }

        case .armed:
            if now.timeIntervalSince(lastFaceSeen) > 60 {
                pause()
                return
            }
            blink.feed(a.eyeOpenness, at: now)
            if a.faceCount == 1,
               let print = a.featurePrint,
               let distance = FaceStore.shared.distance(to: print),
               distance <= FaceStore.shared.effectiveThreshold {
                consecutiveMatches += 1
            } else {
                consecutiveMatches = 0
            }
            let live = !appState.requireBlink || blink.blinked(within: 4)
            if consecutiveMatches >= 3 && live { performUnlock() }

        case .idle, .paused, .typing:
            break
        }
    }

    private func performUnlock() {
        guard let password = cachedPassword else { return }
        scanState = .typing
        stopScanning()
        Unlocker.unlock(password: password)

        // Don't rely on the "unlocked" notification alone: watch the session too.
        Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 2_000_000_000)
            for _ in 0..<25 {
                guard let self, self.scanState == .typing else { return }
                if !Unlocker.isScreenLocked() { self.handleUnlocked(); return }
                try? await Task.sleep(nanoseconds: 300_000_000)
            }
        }
        Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: 9_000_000_000)
            self?.checkUnlockResult()
        }
    }

    private func checkUnlockResult() {
        guard scanState == .typing else { return } // screenUnlocked already fired → success
        failedAttempts += 1
        if failedAttempts >= 2 {
            // Stop before macOS starts rate-limiting password attempts.
            appState.enabled = false
            appState.lastError = "Unlock failed twice, so Face Unlock paused. Check your saved password, then switch it back on."
            scanState = .idle
            updateIcon()
        } else {
            arm()
            startScanning()
        }
    }
}
