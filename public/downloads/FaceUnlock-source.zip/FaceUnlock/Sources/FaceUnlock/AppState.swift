import Foundation
import ServiceManagement

/// Things the UI can ask the app to do.
@MainActor
protocol AppActions: AnyObject {
    func enrollFace()
    func addSamples()
    func testRecognition()
    func setPassword()
    func grantAccessibility()
    func lockNow()
    func setLaunchAtLogin(_ on: Bool)
    func deleteAll()
    func quit()
}

/// Single source of truth the SwiftUI views observe.
@MainActor
final class AppState: ObservableObject {
    weak var actions: AppActions?

    // Setup status
    @Published var enrolled = false
    @Published var hasPassword = false
    @Published var accessibility = false
    @Published var launchAtLogin = false
    @Published var lastError: String?

    // User toggles (persisted)
    @Published var enabled: Bool = Settings.shared.enabled {
        didSet {
            Settings.shared.enabled = enabled
            if enabled { lastError = nil }
        }
    }
    @Published var requireBlink: Bool = Settings.shared.requireBlink {
        didSet { Settings.shared.requireBlink = requireBlink }
    }
    @Published var showAnimation: Bool = Settings.shared.showUnlockAnimation {
        didSet { Settings.shared.showUnlockAnimation = showAnimation }
    }
    @Published var strictness: Strictness = Settings.shared.strictness {
        didSet { Settings.shared.strictness = strictness }
    }

    var isReady: Bool { enrolled && hasPassword && accessibility }

    var setupStepsDone: Int {
        [enrolled, hasPassword, accessibility].filter { $0 }.count
    }

    var statusText: String {
        if lastError != nil { return "Paused after failed unlocks" }
        if !isReady { return "Finish setup · \(setupStepsDone) of 3" }
        return enabled ? "On · unlocks when you return" : "Off"
    }

    func refresh() {
        enrolled = FaceStore.shared.isEnrolled
        accessibility = Unlocker.isTrusted(prompt: false)
        launchAtLogin = SMAppService.mainApp.status == .enabled
    }
}
