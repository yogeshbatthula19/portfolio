import Foundation
import Vision

/// Stores the enrolled face template (a set of feature prints) on disk.
final class FaceStore {
    static let shared = FaceStore()

    private(set) var prints: [VNFeaturePrintObservation] = []
    private let defaults = UserDefaults.standard
    private let thresholdKey = "baseThreshold"

    var isEnrolled: Bool { !prints.isEmpty }

    /// Distance calibrated from your own enrollment samples.
    var baseThreshold: Float {
        let value = defaults.float(forKey: thresholdKey)
        return value > 0 ? value : 0.5
    }

    /// The threshold actually used, after applying the strictness setting.
    var effectiveThreshold: Float { baseThreshold * Settings.shared.strictness.factor }

    private var fileURL: URL {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("FaceUnlock", isDirectory: true)
            .appendingPathComponent("face-template.dat")
    }

    private init() { load() }

    // MARK: Persistence

    private func load() {
        guard let data = try? Data(contentsOf: fileURL),
              let loaded = try? NSKeyedUnarchiver.unarchivedArrayOfObjects(
                ofClass: VNFeaturePrintObservation.self, from: data) else { return }
        prints = loaded
    }

    /// Replace (or, with `append`, extend) the template and recalibrate.
    func save(_ samples: [VNFeaturePrintObservation], append: Bool) throws {
        let all = append ? prints + samples : samples
        let data = try NSKeyedArchiver.archivedData(withRootObject: all, requiringSecureCoding: true)
        let dir = fileURL.deletingLastPathComponent()
        try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        try data.write(to: fileURL, options: [.atomic])
        try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: fileURL.path)
        prints = all
        defaults.set(Self.calibrate(all), forKey: thresholdKey)
    }

    func reset() {
        try? FileManager.default.removeItem(at: fileURL)
        prints = []
        defaults.removeObject(forKey: thresholdKey)
    }

    // MARK: Matching

    /// Lower = more similar. Mean of the 3 closest enrolled samples.
    func distance(to print: VNFeaturePrintObservation) -> Float? {
        Self.score(print, against: prints)
    }

    static func score(_ print: VNFeaturePrintObservation,
                      against refs: [VNFeaturePrintObservation]) -> Float? {
        var distances: [Float] = refs.compactMap { ref -> Float? in
            var d: Float = 0
            do {
                try print.computeDistance(&d, to: ref)
                return d
            } catch {
                return nil
            }
        }
        guard !distances.isEmpty else { return nil }
        distances.sort()
        let k = min(3, distances.count)
        return distances.prefix(k).reduce(0, +) / Float(k)
    }

    /// Leave-one-out: how far is each sample from the rest of your own samples?
    /// The 90th percentile of that becomes the base threshold.
    static func calibrate(_ samples: [VNFeaturePrintObservation]) -> Float {
        guard samples.count >= 2 else { return 0.5 }
        var scores: [Float] = []
        for (i, sample) in samples.enumerated() {
            var others = samples
            others.remove(at: i)
            if let s = score(sample, against: others) { scores.append(s) }
        }
        guard !scores.isEmpty else { return 0.5 }
        scores.sort()
        let index = min(scores.count - 1, Int(Float(scores.count) * 0.9))
        return max(scores[index], 0.05)
    }
}
