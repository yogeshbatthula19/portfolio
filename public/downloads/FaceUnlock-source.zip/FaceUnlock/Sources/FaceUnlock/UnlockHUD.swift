import AppKit
import QuartzCore

/// iPhone-style "unlocked" overlay: a lock that springs open, shown briefly
/// in the middle of the screen right after FaceUnlock unlocks the Mac.
@MainActor
enum UnlockHUD {
    private static var panel: NSPanel?

    static func show() {
        panel?.orderOut(nil)
        guard let screen = NSScreen.main else { return }

        let size = NSSize(width: 200, height: 200)
        let frame = NSRect(x: screen.frame.midX - size.width / 2,
                           y: screen.frame.midY - size.height / 2,
                           width: size.width, height: size.height)

        let hud = NSPanel(contentRect: frame,
                          styleMask: [.borderless, .nonactivatingPanel],
                          backing: .buffered, defer: false)
        hud.level = NSWindow.Level(rawValue: Int(CGShieldingWindowLevel()) + 1) // above everything, incl. the screen saver
        hud.isOpaque = false
        hud.backgroundColor = .clear
        hud.hasShadow = true
        hud.ignoresMouseEvents = true
        hud.collectionBehavior = [.canJoinAllSpaces, .fullScreenAuxiliary, .stationary, .ignoresCycle]

        // Frosted glass: the blur is clipped with a mask image (not a layer mask), so the
        // corners and the window shadow stay perfectly clean.
        let radius: CGFloat = 40
        let background = NSVisualEffectView(frame: NSRect(origin: .zero, size: size))
        background.material = .hudWindow
        background.blendingMode = .behindWindow
        background.state = .active
        let mask = NSImage(size: size, flipped: false) { rect in
            NSColor.black.setFill()
            NSBezierPath(roundedRect: rect, xRadius: radius, yRadius: radius).fill()
            return true
        }
        mask.capInsets = NSEdgeInsets(top: radius, left: radius, bottom: radius, right: radius)
        mask.resizingMode = .stretch
        background.maskImage = mask

        // Glass rim + sheen on top of the blur.
        let rim = NSView(frame: background.bounds)
        rim.wantsLayer = true
        rim.layer?.cornerRadius = radius
        rim.layer?.cornerCurve = .continuous
        rim.layer?.borderWidth = 1
        rim.layer?.borderColor = NSColor.white.withAlphaComponent(0.35).cgColor
        let sheen = CAGradientLayer()
        sheen.frame = rim.bounds
        sheen.colors = [NSColor.white.withAlphaComponent(0.22).cgColor, NSColor.white.withAlphaComponent(0).cgColor]
        sheen.startPoint = CGPoint(x: 0.5, y: 1) // top (layer origin is bottom-left)
        sheen.endPoint = CGPoint(x: 0.5, y: 0.45)
        sheen.cornerRadius = radius
        sheen.cornerCurve = .continuous
        rim.layer?.addSublayer(sheen)

        let symbolConfig = NSImage.SymbolConfiguration(pointSize: 64, weight: .medium)
        let iconFrame = NSRect(x: 50, y: 66, width: 100, height: 100)
        let icon = NSImageView(frame: iconFrame)
        icon.image = symbol("lock.fill", "Locked", symbolConfig)
        icon.contentTintColor = .labelColor
        icon.imageScaling = .scaleProportionallyUpOrDown
        icon.wantsLayer = true

        let label = NSTextField(labelWithString: "Unlocked")
        label.frame = NSRect(x: 10, y: 26, width: 180, height: 24)
        label.alignment = .center
        label.font = .systemFont(ofSize: 17, weight: .semibold)
        label.textColor = .labelColor
        label.alphaValue = 0

        background.addSubview(rim)
        background.addSubview(icon)
        background.addSubview(label)
        hud.contentView = background
        hud.invalidateShadow()
        hud.alphaValue = 0
        hud.orderFrontRegardless()
        panel = hud

        // Scale from the icon's centre rather than its corner.
        if let layer = icon.layer {
            layer.anchorPoint = CGPoint(x: 0.5, y: 0.5)
            layer.position = CGPoint(x: iconFrame.midX, y: iconFrame.midY)
        }

        NSAnimationContext.runAnimationGroup { ctx in
            ctx.duration = 0.18
            hud.animator().alphaValue = 1
        }

        Task { @MainActor in
            // 1. Locked for a moment…
            try? await Task.sleep(nanoseconds: 350_000_000)

            // 2. …springs open and turns green.
            icon.image = symbol("lock.open.fill", "Unlocked", symbolConfig)
            icon.contentTintColor = .systemGreen
            bounce(icon.layer)
            await NSAnimationContext.runAnimationGroup { ctx in
                ctx.duration = 0.25
                label.animator().alphaValue = 1
            }

            // 3. Hold, then fade away.
            try? await Task.sleep(nanoseconds: 1_300_000_000)
            await NSAnimationContext.runAnimationGroup { ctx in
                ctx.duration = 0.35
                hud.animator().alphaValue = 0
            }
            try? await Task.sleep(nanoseconds: 400_000_000)
            hud.orderOut(nil)
            if panel === hud { panel = nil }
        }
    }

    private static func symbol(_ name: String, _ description: String,
                               _ config: NSImage.SymbolConfiguration) -> NSImage? {
        NSImage(systemSymbolName: name, accessibilityDescription: description)?
            .withSymbolConfiguration(config)
    }

    private static func bounce(_ layer: CALayer?) {
        let animation = CAKeyframeAnimation(keyPath: "transform.scale")
        animation.values = [1.0, 1.25, 0.92, 1.04, 1.0]
        animation.keyTimes = [0, 0.3, 0.55, 0.8, 1]
        animation.duration = 0.45
        animation.timingFunction = CAMediaTimingFunction(name: .easeOut)
        layer?.add(animation, forKey: "bounce")
    }
}
