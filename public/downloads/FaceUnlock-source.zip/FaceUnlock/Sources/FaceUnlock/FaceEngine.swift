import CoreGraphics
import CoreImage
import Foundation
import Vision

struct FaceAnalysis {
    var faceCount = 0
    /// Identity "fingerprint" of the largest face (nil if no usable face).
    var featurePrint: VNFeaturePrintObservation?
    /// Eye height / width ratio, averaged over both eyes. Drops sharply during a blink.
    var eyeOpenness: CGFloat?
    /// Width of the largest face as a fraction of the frame width.
    var faceWidthFraction: CGFloat = 0
    /// Nose position relative to the face box centre (−0.5…0.5, y up, camera
    /// not mirrored). Shifts when you turn or tilt your head — used to fill the
    /// enrollment ring like iPhone Face ID.
    var noseOffset: CGPoint?
}

/// On-device face analysis using Apple's Vision framework.
///
/// Vision does not ship a face *identity* model, so we crop the face and use
/// Vision's general-purpose image feature print as an embedding. It is good
/// enough for a personal prototype but is NOT as strong as Face ID.
final class FaceEngine {
    private let ciContext = CIContext()

    func analyze(_ pixelBuffer: CVPixelBuffer) -> FaceAnalysis {
        var result = FaceAnalysis()

        let landmarksRequest = VNDetectFaceLandmarksRequest()
        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])
        do {
            try handler.perform([landmarksRequest])
        } catch {
            return result
        }

        let faces: [VNFaceObservation] = landmarksRequest.results ?? []
        result.faceCount = faces.count
        guard let face = faces.max(by: { area($0.boundingBox) < area($1.boundingBox) }) else {
            return result
        }

        let size = CGSize(width: CVPixelBufferGetWidth(pixelBuffer),
                          height: CVPixelBufferGetHeight(pixelBuffer))
        result.faceWidthFraction = face.boundingBox.width
        result.eyeOpenness = Self.eyeOpenness(of: face, imageSize: size)
        if let nose = face.landmarks?.nose ?? face.landmarks?.noseCrest {
            let pts = nose.normalizedPoints // relative to the face box, origin bottom-left
            if !pts.isEmpty {
                let n = CGFloat(pts.count)
                let cx = pts.reduce(0) { $0 + $1.x } / n
                let cy = pts.reduce(0) { $0 + $1.y } / n
                result.noseOffset = CGPoint(x: cx - 0.5, y: cy - 0.5)
            }
        }
        result.featurePrint = featurePrint(of: face, in: pixelBuffer, imageSize: size)
        return result
    }

    private func area(_ r: CGRect) -> CGFloat { r.width * r.height }

    private func featurePrint(of face: VNFaceObservation,
                              in pixelBuffer: CVPixelBuffer,
                              imageSize: CGSize) -> VNFeaturePrintObservation? {
        let image = CIImage(cvPixelBuffer: pixelBuffer)
        // Vision and Core Image both use a bottom-left origin, so the rect maps directly.
        var rect = VNImageRectForNormalizedRect(face.boundingBox,
                                                Int(imageSize.width), Int(imageSize.height))
        rect = rect.insetBy(dx: -rect.width * 0.15, dy: -rect.height * 0.15)
            .intersection(image.extent)
        guard !rect.isNull, rect.width >= 60, rect.height >= 60 else { return nil }

        // Greyscale crop: reduces sensitivity to coloured lighting.
        let crop = image.cropped(to: rect)
            .applyingFilter("CIColorControls", parameters: [kCIInputSaturationKey: 0.0])
        guard let cgImage = ciContext.createCGImage(crop, from: crop.extent) else { return nil }

        let request = VNGenerateImageFeaturePrintRequest()
        request.imageCropAndScaleOption = .scaleFill
        do {
            try VNImageRequestHandler(cgImage: cgImage, options: [:]).perform([request])
        } catch {
            return nil
        }
        return request.results?.first
    }

    static func eyeOpenness(of face: VNFaceObservation, imageSize: CGSize) -> CGFloat? {
        guard let landmarks = face.landmarks,
              let left = landmarks.leftEye,
              let right = landmarks.rightEye,
              let l = ratio(left, imageSize), let r = ratio(right, imageSize) else { return nil }
        return (l + r) / 2
    }

    private static func ratio(_ region: VNFaceLandmarkRegion2D, _ imageSize: CGSize) -> CGFloat? {
        let points = region.pointsInImage(imageSize: imageSize)
        guard points.count >= 4,
              let minX = points.map(\.x).min(), let maxX = points.map(\.x).max(),
              let minY = points.map(\.y).min(), let maxY = points.map(\.y).max(),
              maxX - minX > 0 else { return nil }
        return (maxY - minY) / (maxX - minX)
    }
}

/// Simple liveness check: looks for an open → closed → open eye transition.
/// A printed photo can't blink. (A video on a phone still can — see README.)
final class BlinkDetector {
    private var openBaseline: CGFloat = 0
    private var closedAt: Date?
    private(set) var lastBlink: Date?

    func reset() {
        openBaseline = 0
        closedAt = nil
        lastBlink = nil
    }

    func feed(_ openness: CGFloat?, at now: Date = Date()) {
        guard let openness else { return }
        if openBaseline == 0 {
            openBaseline = openness
            return
        }
        // Track the "eyes open" level slowly so lighting/pose drift doesn't break it.
        if openness > openBaseline * 0.85 {
            openBaseline = openBaseline * 0.8 + openness * 0.2
        }
        if openness < openBaseline * 0.65 {
            if closedAt == nil { closedAt = now }
        } else if let closed = closedAt, openness > openBaseline * 0.85 {
            if now.timeIntervalSince(closed) < 0.8 { lastBlink = now }
            closedAt = nil
        }
    }

    func blinked(within seconds: TimeInterval) -> Bool {
        guard let lastBlink else { return false }
        return Date().timeIntervalSince(lastBlink) <= seconds
    }
}
