import AVFoundation
import CoreVideo
import Foundation

/// Owns the webcam session, throttles frames, runs face analysis off the main
/// thread and hands results back on the main actor.
final class CameraManager: NSObject, AVCaptureVideoDataOutputSampleBufferDelegate {
    let session = AVCaptureSession()

    private let output = AVCaptureVideoDataOutput()
    private let sessionQueue = DispatchQueue(label: "faceunlock.camera.session")
    private let videoQueue = DispatchQueue(label: "faceunlock.camera.video")
    private let engine = FaceEngine()
    private var configured = false
    private var lastFrame = Date.distantPast
    private var wanted = false // only touched on sessionQueue

    override init() {
        super.init()
        let nc = NotificationCenter.default
        // After sleep / lid close the session can error out or stay interrupted.
        nc.addObserver(forName: .AVCaptureSessionRuntimeError, object: session, queue: nil) { [weak self] _ in
            self?.restart()
        }
        nc.addObserver(forName: .AVCaptureSessionInterruptionEnded, object: session, queue: nil) { [weak self] _ in
            self?.restart()
        }
    }

    private let lock = NSLock()
    private var _onAnalysis: (@MainActor (FaceAnalysis) -> Void)?
    private var _minFrameInterval: TimeInterval = 0.15

    /// Called on the main actor with each analysed frame.
    var onAnalysis: (@MainActor (FaceAnalysis) -> Void)? {
        get { lock.lock(); defer { lock.unlock() }; return _onAnalysis }
        set { lock.lock(); _onAnalysis = newValue; lock.unlock() }
    }

    /// Minimum seconds between analysed frames (lower = better blink detection, more CPU).
    var minFrameInterval: TimeInterval {
        get { lock.lock(); defer { lock.unlock() }; return _minFrameInterval }
        set { lock.lock(); _minFrameInterval = newValue; lock.unlock() }
    }

    static func requestAccess(_ completion: @escaping @MainActor (Bool) -> Void) {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            Task { @MainActor in completion(true) }
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                Task { @MainActor in completion(granted) }
            }
        default:
            Task { @MainActor in completion(false) }
        }
    }

    /// Stops and starts the session again (only if someone still wants it running).
    func restart() {
        sessionQueue.async {
            guard self.wanted else { return }
            if self.session.isRunning { self.session.stopRunning() }
            usleep(300_000)
            do {
                try self.configureIfNeeded()
                self.session.startRunning()
            } catch {
                NSLog("FaceUnlock: camera restart failed: \(error)")
            }
        }
    }

    func start() {
        sessionQueue.async {
            self.wanted = true
            do {
                try self.configureIfNeeded()
                if !self.session.isRunning { self.session.startRunning() }
            } catch {
                NSLog("FaceUnlock: camera start failed: \(error)")
            }
        }
    }

    func stop() {
        sessionQueue.async {
            self.wanted = false
            if self.session.isRunning { self.session.stopRunning() }
        }
    }

    private func configureIfNeeded() throws {
        guard !configured else { return }
        guard let device = AVCaptureDevice.default(for: .video) else {
            throw NSError(domain: "FaceUnlock", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "No camera found"])
        }
        session.beginConfiguration()
        if session.canSetSessionPreset(.vga640x480) {
            session.sessionPreset = .vga640x480
        } else {
            session.sessionPreset = .high
        }
        let input = try AVCaptureDeviceInput(device: device)
        if session.canAddInput(input) { session.addInput(input) }

        output.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA]
        output.alwaysDiscardsLateVideoFrames = true
        output.setSampleBufferDelegate(self, queue: videoQueue)
        if session.canAddOutput(output) { session.addOutput(output) }
        session.commitConfiguration()
        configured = true
    }

    // MARK: AVCaptureVideoDataOutputSampleBufferDelegate

    func captureOutput(_ output: AVCaptureOutput,
                       didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {
        let now = Date()
        guard now.timeIntervalSince(lastFrame) >= minFrameInterval,
              let handler = onAnalysis,
              let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        lastFrame = now

        let analysis = engine.analyze(pixelBuffer)
        Task { @MainActor in handler(analysis) }
    }
}
