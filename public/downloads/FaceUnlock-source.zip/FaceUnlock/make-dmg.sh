#!/usr/bin/env bash
# Builds FaceUnlock.app and packages it as a drag-to-install DMG.
# Output: build/FaceUnlock.dmg
set -euo pipefail
cd "$(dirname "$0")"

VERSION="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' Resources/Info.plist)"
DMG="build/FaceUnlock-${VERSION}.dmg"
STAGE="build/dmg-stage"

./build.sh

echo "▶ Packaging DMG…"
rm -rf "$STAGE" "$DMG"
mkdir -p "$STAGE"
cp -R build/FaceUnlock.app "$STAGE/"
ln -s /Applications "$STAGE/Applications"   # drag-to-install shortcut

hdiutil create \
  -volname "Face Unlock" \
  -srcfolder "$STAGE" \
  -fs HFS+ \
  -format UDZO \
  -ov "$DMG" >/dev/null

rm -rf "$STAGE"
codesign --force --sign "${SIGN_IDENTITY:--}" "$DMG"

echo "✅ $DMG ($(du -h "$DMG" | cut -f1))"
open -R "$DMG"
